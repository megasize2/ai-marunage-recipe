================================================================
 日英ホラー文字演出 動くAPNG素材集 56  ―  APNG + WebP
 YKのAI素材工房  https://yk-ai-sozai.booth.pm/
================================================================

 このZIPは無料お試し版です。8スタイルから1種ずつ、計8種が入っています。

   apng/ … APNG版
   webp/ … WebP版

 まずはココフォリアに置いて、実際に動くかお確かめください。
 完全版は 8スタイル × 7種 = 全56種です。

■ 仕様
  960x540 / 透過ループ / 約1.4〜1.8秒周期 / 継ぎ目なし
  背景は透過なので、既存の全画面演出素材の**上に重ねて**使えます

■ 使い方
  ココフォリア … 通常の画像と同じ手順で追加するだけ
  OBS ………… 「画像」ソースに指定するだけ

■ 収録リスト

■ t01 血文字がにじみ出る
  t01-01  助けて / HELP ME
  t01-02  死 / DIE
  t01-03  私を殺して / KILL ME
  t01-04  まだ生きてる / STILL ALIVE
  t01-05  出ていけ / GET OUT
  t01-06  嘘つき / LIAR
  t01-07  お前の番 / YOUR TURN

■ t02 グリッチ分解
  t02-01  逃げろ / RUN
  t02-02  どこにも行けない / NO WAY OUT
  t02-03  終わりだ / IT'S OVER
  t02-04  誰もいない / NOBODY HERE
  t02-05  気づかれた / IT SAW YOU
  t02-06  帰れない / CAN'T GO HOME
  t02-07  数えるな / DON'T COUNT

■ t03 高速点滅（サブリミナル）
  t03-01  逃げろ / RUN
  t03-02  見るな / DON'T LOOK
  t03-03  後ろ / BEHIND YOU
  t03-04  死 / DIE
  t03-05  来るな / STAY AWAY
  t03-06  隠れろ / HIDE
  t03-07  走り続けろ / KEEP RUNNING

■ t04 引っかき書き（手書き）
  t04-01  助けて / HELP ME
  t04-02  開けるな / DON'T OPEN
  t04-03  一人じゃない / NOT ALONE
  t04-04  名前を呼ぶな / DON'T SAY MY NAME
  t04-05  ここにいる / I AM HERE
  t04-06  忘れろ / FORGET IT
  t04-07  逃げ場はない / NOWHERE TO RUN

■ t05 ノイズ砂嵐から浮かぶ
  t05-01  呼ばれてる / IT CALLS YOU
  t05-02  思い出せ / REMEMBER
  t05-03  戻れ / GO BACK
  t05-04  目を閉じるな / DON'T BLINK
  t05-05  まだ終わってない / NOT OVER YET
  t05-06  息を止めろ / HOLD YOUR BREATH
  t05-07  こっちを見て / LOOK AT ME

■ t06 タイプライター
  t06-01  静かに / BE QUIET
  t06-02  もう遅い / TOO LATE
  t06-03  思い出せ / REMEMBER
  t06-04  逃げ場はない / NOWHERE TO RUN
  t06-05  息を止めろ / HOLD YOUR BREATH
  t06-06  お前の番 / YOUR TURN
  t06-07  終わりだ / IT'S OVER

■ t07 ネオン管の明滅
  t07-01  出ていけ / GET OUT
  t07-02  戻れ / GO BACK
  t07-03  来るな / STAY AWAY
  t07-04  静かに / BE QUIET
  t07-05  どこにも行けない / NO WAY OUT
  t07-06  目を閉じるな / DON'T BLINK
  t07-07  開けるな / DON'T OPEN

■ t08 鏡文字・反転
  t08-01  振り向くな / DON'T TURN AROUND
  t08-02  後ろ / BEHIND YOU
  t08-03  こっちを見て / LOOK AT ME
  t08-04  一人じゃない / NOT ALONE
  t08-05  逃げろ / RUN
  t08-06  見るな / DON'T LOOK
  t08-07  ここにいる / I AM HERE

■ 利用条件
  ・TRPGセッション(オンライン/オフライン)、配信、動画、同人シナリオ同梱OK(商用可)
  ・クレジット表記は不要です
  ・素材そのものの再配布・再販売は禁止です

■ 制作について
  画像生成AIは使っていません。文字はWindows同梱フォントの字形を、
  にじみ・掠れ・ノイズ・グリッチはすべて AI(Claude) が書いた Python コードで
  描いています。AI生成作品です。
  制作の裏側はnoteで連載しています: https://note.com/firm_rue7725
================================================================
